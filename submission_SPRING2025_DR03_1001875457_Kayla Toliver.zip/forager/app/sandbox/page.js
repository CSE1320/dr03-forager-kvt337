import Message from "../../components/Message";
import Button from "../../components/Button";
import Postcard from "../../components/Postcard";
import MushroomList from "@/components/MushroomList";
import PageTitle from "@/components/PageTitle";
import SearchBar from "@/components/SearchBar";
import ComparisonTable from "@/components/ComparisonTable";
export default function SandboxPage() {
    return (
      <div className="page flex justify-center items-center flex-row flex-nowrap">
      {/* <Message/> */}
      {/* <Button/> */}
      {/* <Postcard/> */}
      {/* <MushroomList/> */}
      {/* <PageTitle/> */}
      {/* <SearchBar/> */}
      <ComparisonTable/>
      </div>
    );
}
  